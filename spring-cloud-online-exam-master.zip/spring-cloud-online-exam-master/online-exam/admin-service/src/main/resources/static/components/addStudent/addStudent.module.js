'user strict';

angular.module('addStudent', []);