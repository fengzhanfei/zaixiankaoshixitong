'use strict'

/**
 * 试卷题目模块
 * 查看某试卷的所有题目
 */

angular.module('paperQuestions', []);