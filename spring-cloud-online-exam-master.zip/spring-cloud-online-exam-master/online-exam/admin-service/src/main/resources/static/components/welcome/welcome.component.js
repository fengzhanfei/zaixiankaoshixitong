'use strict';

angular.module('welcome')
    .component('welcome', {
        templateUrl: 'components/welcome/welcome.template.html',
        controller: function WelcomeController($scope) {

        }
    });