'user strict';

angular.module('students', []);