'user strict';

angular.module('results', []);