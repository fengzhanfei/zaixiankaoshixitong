'user strict';

angular.module('authority', []);