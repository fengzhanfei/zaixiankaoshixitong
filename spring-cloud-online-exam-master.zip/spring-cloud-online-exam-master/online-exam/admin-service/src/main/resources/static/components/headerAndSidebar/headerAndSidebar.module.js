'user strict';

angular.module('headerAndSidebar', []);