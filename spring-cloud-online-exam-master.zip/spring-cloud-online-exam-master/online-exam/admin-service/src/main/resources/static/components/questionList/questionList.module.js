'use strict'

angular.module('questionList', []);