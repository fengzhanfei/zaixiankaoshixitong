'use strict';

angular.module('answerPapers', []);