'user strict';

angular.module('userInfo', []);