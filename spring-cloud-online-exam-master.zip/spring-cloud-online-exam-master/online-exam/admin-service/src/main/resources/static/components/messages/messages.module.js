'use strict';

angular.module('messages', []);