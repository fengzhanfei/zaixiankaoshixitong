'user strict';

angular.module('subjects', []);