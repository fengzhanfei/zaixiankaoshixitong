'user strict';

angular.module('paperList', []);