'user strict';

angular.module('addQuestion', []);