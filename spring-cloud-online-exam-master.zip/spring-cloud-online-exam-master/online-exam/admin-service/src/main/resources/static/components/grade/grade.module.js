'user strict';

angular.module('grade', []);