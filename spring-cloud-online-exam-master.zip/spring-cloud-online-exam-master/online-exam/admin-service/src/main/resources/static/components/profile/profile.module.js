'use strict';

angular.module('profile', []);