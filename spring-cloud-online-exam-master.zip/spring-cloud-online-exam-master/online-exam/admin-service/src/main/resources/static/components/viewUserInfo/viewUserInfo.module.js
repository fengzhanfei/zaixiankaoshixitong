'user strict';

angular.module('viewUserInfo', []);