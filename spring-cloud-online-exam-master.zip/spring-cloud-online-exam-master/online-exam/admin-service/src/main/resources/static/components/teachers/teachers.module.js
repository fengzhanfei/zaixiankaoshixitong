'use strict'

angular.module('teachers', []);