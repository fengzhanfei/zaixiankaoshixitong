'use strict';

angular.module('changePassword', []);