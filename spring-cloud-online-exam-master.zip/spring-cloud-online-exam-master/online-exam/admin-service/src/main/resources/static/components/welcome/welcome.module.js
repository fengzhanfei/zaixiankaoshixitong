'use strict';

angular.module('welcome', []);