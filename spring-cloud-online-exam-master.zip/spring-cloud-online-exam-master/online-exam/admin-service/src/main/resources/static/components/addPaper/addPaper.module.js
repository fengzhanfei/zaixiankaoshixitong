'user strict';

angular.module('addPaper', []);