'user strict';

angular.module('gradeList', []);