'use strict';

angular.module('markPaper', []);