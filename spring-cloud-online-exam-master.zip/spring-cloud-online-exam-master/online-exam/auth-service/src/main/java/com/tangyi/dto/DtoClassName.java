package com.tangyi.dto;

/**
 * Created by tangyi on 2017/3/4.
 */
public class DtoClassName {

    private String label;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
