package com.tangyi.domain;

/**
 * Created by tangyi on 2017/3/25.
 */
public class GradeClassName {
    private Long id;

    private String gradeId;

    private String classnameId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGradeId() {
        return gradeId;
    }

    public void setGradeId(String gradeId) {
        this.gradeId = gradeId;
    }

    public String getClassnameId() {
        return classnameId;
    }

    public void setClassnameId(String classnameId) {
        this.classnameId = classnameId;
    }
}
