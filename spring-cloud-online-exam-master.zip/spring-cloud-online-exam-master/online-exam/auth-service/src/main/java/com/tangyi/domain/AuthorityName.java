package com.tangyi.domain;

/**
 * Created by tangyi on 2017/3/8.
 */
public enum AuthorityName {
    ROLE_USER, ROLE_ADMIN,ROLE_STUDENT,ROLE_TEACHER
}
