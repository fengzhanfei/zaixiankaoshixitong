package com.tangyi.constant;

/**
 * Created by tangyi on 2017-04-20.
 */
public class Role {

    public static final String ROLE_ADMIN = "ROLE:ADMIN";

    public static final String ROLE_TEACHER = "ROLE:TEACHER";

    public static final String ROLE_STUDENT = "ROLE:STUDENT";

}
