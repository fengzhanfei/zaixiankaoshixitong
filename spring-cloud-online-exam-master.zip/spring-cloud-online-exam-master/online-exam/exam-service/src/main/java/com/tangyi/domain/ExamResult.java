package com.tangyi.domain;

/**
 * 考试结果实体类
 * Created by tangyi on 2017/3/29.
 */
public class ExamResult {
    /*考试得分*/
    private String score;

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }
}
