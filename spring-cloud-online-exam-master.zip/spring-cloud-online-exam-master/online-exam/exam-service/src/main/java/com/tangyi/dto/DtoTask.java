package com.tangyi.dto;

/**
 * Created by tangyi on 2017-04-08.
 */
public class DtoTask {
    private double checked;

    private double unChecked;

    public double getChecked() {
        return checked;
    }

    public void setChecked(double checked) {
        this.checked = checked;
    }

    public double getUnChecked() {
        return unChecked;
    }

    public void setUnChecked(double unChecked) {
        this.unChecked = unChecked;
    }
}
