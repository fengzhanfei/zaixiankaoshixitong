'use strict';

angular.module('wrongs', []);