'use strict';

angular.module('simulateList', []);