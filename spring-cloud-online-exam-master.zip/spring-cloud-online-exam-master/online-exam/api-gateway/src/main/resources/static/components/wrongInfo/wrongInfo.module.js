'use strict';

angular.module('wrongInfo', []);