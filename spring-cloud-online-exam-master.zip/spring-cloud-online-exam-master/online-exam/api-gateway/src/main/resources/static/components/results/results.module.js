'use strict';

angular.module('results', []);