'use strict';

angular.module('features', []);