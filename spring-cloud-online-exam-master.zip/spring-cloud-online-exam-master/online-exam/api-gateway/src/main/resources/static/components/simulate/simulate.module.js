'use strict';

angular.module('simulate', []);