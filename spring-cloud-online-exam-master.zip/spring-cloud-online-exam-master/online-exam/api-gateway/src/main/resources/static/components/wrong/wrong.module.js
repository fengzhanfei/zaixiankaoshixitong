'use strict';

angular.module('wrong', []);