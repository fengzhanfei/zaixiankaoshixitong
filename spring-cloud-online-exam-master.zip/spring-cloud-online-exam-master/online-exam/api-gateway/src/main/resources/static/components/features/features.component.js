'use strict';

angular.module('features').
component('features', {
    templateUrl: 'components/features/features.template.html',
    controller: function FeaturesController($scope, $http, $rootScope) {


    }
});
