'use strict';

// 引入各个依赖模块
angular.module('contentApp', ['ngAnimate', 'ngSanitize', 'ui.router', 'LocalStorageModule',
	, 'smart-table', 'timer', 'mgcrea.ngStrap.modal', 'Tek.progressBar',
	'header'
	,'home', 'features', 'recently', 'simulateList', 'recordList', 'exam', 'results', 'simulate', 'practiceList', 'practice',
	'wrong', 'wrongs', 'wrongInfo'
]);
