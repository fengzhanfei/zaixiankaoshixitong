'use strict';

angular.module('recently', []);