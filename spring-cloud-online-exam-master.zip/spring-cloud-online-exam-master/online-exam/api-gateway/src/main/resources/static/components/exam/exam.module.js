'use strict';

angular.module('exam', []);