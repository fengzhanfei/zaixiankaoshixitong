'use strict';

/**
 * 考试记录模块
 * 展示某人的考试记录，按时间排序
 */
angular.module('recordList', []);