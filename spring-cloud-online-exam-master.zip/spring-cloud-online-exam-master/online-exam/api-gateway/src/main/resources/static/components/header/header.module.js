'user strict';

angular.module('header', []);