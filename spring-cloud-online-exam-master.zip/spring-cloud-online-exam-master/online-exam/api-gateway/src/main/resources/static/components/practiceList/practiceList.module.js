'use strict';

angular.module('practiceList', []);