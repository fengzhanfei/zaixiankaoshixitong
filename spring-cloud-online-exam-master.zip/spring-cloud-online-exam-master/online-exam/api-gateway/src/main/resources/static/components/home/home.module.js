'use strict';

angular.module('home', []);