'use strict';

angular.module('practice', []);